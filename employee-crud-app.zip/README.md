# Employee Management CRUD Application (Spring Boot & MongoDB)

This is a simple CRUD (Create, Read, Update, Delete) application for managing employee details.

## Technology Stack

*   **Backend:** Java, Spring Boot, Spring Data MongoDB, Spring Security, JWT
*   **Database:** MongoDB
*   **Build Tool:** Maven

## Deployment on Railway

This project is configured to be easily deployed on the Railway platform.

**Key Deployment Requirements:**

1.  **MongoDB Connection:** The application requires a MongoDB connection string. This should be set as an environment variable named `SPRING_DATA_MONGODB_URI` in your Railway project.
2.  **Java Version:** The project requires **Java 24** (as specified in `pom.xml`). Railway will automatically detect and use the correct Java version.

For detailed deployment instructions, please refer to the guide provided by the agent.
